const grid=document.getElementById('productsGrid'), search=document.getElementById('search');
async function loadProducts(url='/api/products'){const r=await fetch(url);const products=await r.json();grid.innerHTML=products.map(p=>`
<div class="card"><img src="${p.imageUrl}" alt="${p.name}"><div class="card-body"><span class="pill">${p.category}</span>
<h3>${p.name}</h3><p>${p.brand}</p><div class="price">₹${p.pricePerDay}/day</div>
<p>${p.available?'Available':'Unavailable'}</p><a class="btn" href="product.html?id=${p.id}">View Details</a></div></div>`).join('')||'<p>No products found.</p>'}
loadProducts(); search.addEventListener('input',()=>{const q=search.value.trim();loadProducts(q?'/api/products/search?q='+encodeURIComponent(q):'/api/products')});
